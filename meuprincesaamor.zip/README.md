Para Minha Princesa - site romântico
Arquivos:
- index.html
- foto1.png ... foto5.png
Como publicar: faça upload dos arquivos no repositório GitHub e conecte ao Vercel.
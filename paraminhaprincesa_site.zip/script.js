const messageEl = document.getElementById('message');
const revealBtn = document.getElementById('revealBtn');
const content = document.getElementById('content');

const photos = [
  'images/photo1.png',
  'images/photo2.png',
  'images/photo3.png',
  'images/photo4.png',
  'images/photo5.png',
  'images/photo6.png',
  'images/photo7.png'
];

// typing animation
const text = "Eu te amo muito e te admiro demais.\nVocê é a melhor parte da minha vida. 💕";
let idx = 0;
function typeNext(){
  if(idx <= text.length){
    messageEl.textContent = text.slice(0, idx);
    idx++;
    setTimeout(typeNext, 28);
  }
}
typeNext();

// build slides
const slidesContainer = document.querySelector('.slides');
photos.forEach(src=>{
  const img = document.createElement('img');
  img.src = src;
  slidesContainer.appendChild(img);
});

// simple carousel control
let current = 0;
const total = photos.length;
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');

function update(){
  const slideWidth = slidesContainer.children[0].getBoundingClientRect().width + 12;
  slidesContainer.style.transform = `translateX(${ -current * slideWidth }px)`;
}
window.addEventListener('resize', update);

prevBtn.addEventListener('click', ()=>{
  current = (current - 1 + total) % total;
  update();
});
nextBtn.addEventListener('click', ()=>{
  current = (current + 1) % total;
  update();
});

// reveal button
revealBtn.addEventListener('click', ()=>{
  content.classList.remove('hidden');
  // scroll to content
  content.scrollIntoView({behavior:'smooth', block:'center'});
  // try a gentle pulse on the btn
  revealBtn.animate([{transform:'scale(1)'},{transform:'scale(0.98)'},{transform:'scale(1)'}],{duration:420});
});

// auto-advance slides every 4.5s
setInterval(()=>{ current = (current + 1) % total; update(); }, 4500);

// initial small delay to show first slide properly
setTimeout(update, 300);

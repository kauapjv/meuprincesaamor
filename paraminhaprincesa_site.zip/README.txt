Paraminhaprincesa - Site romântico (deploy rápido no Vercel)
====================================

Como usar:
1) Faça o download deste ZIP e extraia.
2) Entre em https://vercel.com e faça login (Google/GitHub).
3) No Dashboard clique em "New Project" -> "Import" -> "Upload" (ou "Deploy" e depois "Upload").
4) Arraste a pasta do projeto (ou selecione o arquivo) e confirme.
5) Após deploy, seu site ficará com um endereço do tipo: https://paraminhaprincesa-yourname.vercel.app
   - Para usar exatamente paraminhaprincesa.vercel.app você pode configurar um domínio personalizado no Vercel (opcional).

Observações:
- A música está embutida via player do Spotify (iframe). Em alguns navegadores o áudio não inicia automaticamente; basta clicar no play dentro do player.
- Se quiser que eu mude textos, ordem das fotos ou aparências, me fale que eu atualizo os arquivos.
